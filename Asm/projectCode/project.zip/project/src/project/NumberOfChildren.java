package project;

public class NumberOfChildren {

	String className;
	String extendClassName;
	
}
