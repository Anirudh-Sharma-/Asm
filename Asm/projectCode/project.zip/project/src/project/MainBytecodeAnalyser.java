package project;

import java.io.PrintStream;
import java.util.Date;

import org.objectweb.asm.ClassVisitor;

//import util.ClassFileOpener;














import project.ClassComplexityCounter;
import project.MainBytecodeAnalyser;

public class MainBytecodeAnalyser {
	
	

	/**
	 * @param args  A list of class/jar files to process
	 */
	public static void main(String[] args) 
	{
		if (args.length == 0) {
			System.err.println("MainBytecodeAnalyser error: run with some .class files as arguments.");
			return;
		}
		MainBytecodeAnalyser instance = new MainBytecodeAnalyser();
		instance.visitAllFiles(System.out, args);
	}
	

	protected void visitAllFiles(PrintStream outfile, String[] filesToAnalyse) 
	{
		ClassVisitor visitor = new ClassComplexityCounter(outfile);
		outfile.printf("Date, \"%s\"\n", new Date());
		System.out.println("**************************************************");
		ClassFileOpener opener = new ClassFileOpener(visitor);
		for (String fileName : filesToAnalyse) {
			opener.open(fileName);
		}
		System.out.println("##### Characteristics Matrix: #####");
		System.out.println("[1] No. of attributes: " + ClassComplexityCounter.fieldCount);
		System.out.println("[2] No. of getters and setters: " + ClassComplexityCounter.setGetMethodCount);    		
		ClassComplexityCounter.methodCount = ClassComplexityCounter.methodCount - ClassComplexityCounter.setGetMethodCount;
		System.out.println("[3] No. of methods: " + ClassComplexityCounter.methodCount );
		int packageInterfaceUsage = 0;
		if(ClassComplexityCounter.interfaceUsage){
			 packageInterfaceUsage = 1;
		}else{
			 packageInterfaceUsage = 0;
		}
		System.out.println("[4] Interface Usage: " + packageInterfaceUsage);
		int packageSuperclassUsage = 0;
		if(ClassComplexityCounter.superclassUsage){
			packageSuperclassUsage = 1;
		}else{
			packageSuperclassUsage = 0;
		}
		
		System.out.println("[5] Superclass Usage: " + packageSuperclassUsage);		
		System.out.println("[6] No. of static attributes: " + ClassComplexityCounter.staticFieldCount);
		System.out.println("[7] No. of static methods: " + ClassComplexityCounter.staticMethodCount);
		double meanMethodComplexity = (ClassComplexityCounter.methodsComplexity/(ClassComplexityCounter.methodCount + ClassComplexityCounter.setGetMethodCount));
		System.out.println("[8] Mean method Complexity: " + meanMethodComplexity);
		double methodsMeanSize = ((ClassComplexityCounter.totalLinesOfMethods)/(ClassComplexityCounter.methodCount+ClassComplexityCounter.setGetMethodCount));
		System.out.println("[9] Class methods mean size: " + methodsMeanSize);
		ClassComplexityCounter.totalLinesOfCode = ClassComplexityCounter.totalLinesOfCode + ClassComplexityCounter.totalLinesOfMethods;
		System.out.println("[10] Total Lines Of Code: " + ClassComplexityCounter.totalLinesOfCode);
		System.out.println("[11] Weighted Methods per Class: " + ClassComplexityCounter.methodsComplexity);
		
		for(int i = 0; i < ClassComplexityCounter.overridenMethod.size(); i++){
			String className = ClassComplexityCounter.overridenMethod.get(i).className;
			int j = i;
			for(int k = 0; k < ClassComplexityCounter.overridenMethod.size(); k++){
				if(j == k){
		           continue;
				}
				if(className.equals(ClassComplexityCounter.overridenMethod.get(k).extendClass)){
					if(ClassComplexityCounter.overridenMethod.get(i).methodName.equals(ClassComplexityCounter.overridenMethod.get(k).methodName)){
						ClassComplexityCounter.overridenMethCount++;
					}
				}
			}
		}
		System.out.println("[12] No. of Overriden Methods: " + ClassComplexityCounter.overridenMethCount); 
		
		
		for(int i = 0; i < ClassComplexityCounter.numbOfChild.size(); i++){
			
			NumberOfChildren tmp = ClassComplexityCounter.numbOfChild.get(i);
			String defaultSuperClass = "java/lang/Object";
			if(!(tmp.extendClassName.equals(defaultSuperClass))){
				continue;
			}
			String currentClass = tmp.className;   			
			int j = i;
            for(int k = 0; k < ClassComplexityCounter.numbOfChild.size(); k++){
            	if(k == j){
            		continue;
            	}
            	NumberOfChildren tmpOne = ClassComplexityCounter.numbOfChild.get(k);
            	if(currentClass.equals(tmpOne.extendClassName)){
            		ClassComplexityCounter.NoOfChildrenCount++;
            	}
            }
			
		}
		
		System.out.println("[13] No. of Children: " + ClassComplexityCounter.NoOfChildrenCount);
		
		
		
	}	

}
