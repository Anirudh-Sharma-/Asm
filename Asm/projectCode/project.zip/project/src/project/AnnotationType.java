package project;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Attribute;
import org.objectweb.asm.Handle;
import org.objectweb.asm.AnnotationVisitor;

import project.ClassComplexityCounter;

public class AnnotationType extends AnnotationVisitor{
	
	
	public AnnotationType(int api) 
	{
		super(Opcodes.ASM4);
		
		
	}

}
