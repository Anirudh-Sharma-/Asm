package project;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ArrayList;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import project.MethodComplexityCounter;

public class ClassComplexityCounter extends ClassVisitor  {
	boolean packageChange = false;
	//int fileCount = 0;
	static ArrayList<String> packageName = new ArrayList<String>();
	static ArrayList<String> fieldname = new ArrayList<String>();
	static ArrayList<String> superclasses = new ArrayList<String>();
	static ArrayList<OverridenMethods> overridenMethod = new ArrayList<OverridenMethods>();
	static ArrayList<IntfOvrdnMth> indIntfClassMth = new ArrayList<IntfOvrdnMth>();
	static ArrayList<String> classMethods = new ArrayList<String>();
	static ArrayList<NumberOfChildren> numbOfChild = new ArrayList<NumberOfChildren>();
	String currentClassName;
	Map<String, Integer> methodCounts;
	PrintStream outfile;
	String currentFieldName;
	String currentMethodName;
	 static int fieldCount = 0;
	 static int methodCount = 0;
	 static int setGetMethodCount = 0;
	 static int staticFieldCount = 0;
	 static int staticMethodCount = 0;
	 static double methodsComplexity = 0;
	 static int totalLinesOfCode = 0;
	 static int totalLinesOfMethods = 0;
	 static boolean interfaceUsage = false;
	 static boolean superclassUsage = false;
	 public OverridenMethods ovrMeth;
	 static int overridenMethCount = 0;
	 static String ovrClassName;
	 static String ovrMethName;
	 static String ovrExtClass;
	 public IntfOvrdnMth intfOvrdnMth;
	 static boolean interfaceEncountered = false;
	 public NumberOfChildren noc;
	 static int NoOfChildrenCount;

    public ClassComplexityCounter(PrintStream outfile) {
        super(Opcodes.ASM4);
    	this.methodCounts = new HashMap<String, Integer>();
    	this.outfile = outfile;
    }

    @Override
    public void visit(int version, int access, String name,
                    String signature, String superName, String[] interfaces) 
    {
    	
    	
    	
    	//System.out.println(version + " : " + access + " : " + name + " : " + signature + " : " + superName);
    	int currentAccess = 1537;
    	int currentAccessClass = 33;
    	if(access == currentAccess){
    		this.intfOvrdnMth = new IntfOvrdnMth();
    		this.intfOvrdnMth.intfName = name;
    		this.intfOvrdnMth.IndintfMthCount = 0;
    		interfaceEncountered = true;
    		
    	}
    	
    	if(access == currentAccessClass){
    		for(int i = 0; i < indIntfClassMth.size(); i++){
    			String interfaceName = indIntfClassMth.get(i).intfName;
    			for(int j = 0; j < interfaces.length; j++){
    				if(interfaces[j].equals(interfaceName)){
    					overridenMethCount += indIntfClassMth.get(i).IndintfMthCount;
    				}
    			}
    		}
    		
    		this.noc = new NumberOfChildren();
    		this.noc.className = name;
    		this.noc.extendClassName = superName;
    		numbOfChild.add(this.noc);
    		
    		
    	}
    	
    	ovrClassName = name;

    	
    	this.currentClassName  = name;
        if(interfaces.length > 0){
        	interfaceUsage = true;
        }
        
        String[] superclassPath = superName.split("/");
        String superclass = superclassPath[superclassPath.length-1];
        String defaultSuperclass = "Object";
     //   System.out.println("------" + superclass);
        if(!(superclass.equals(defaultSuperclass) )){
        	superclasses.add(superclass);
     //   	for(int i = 0; i < superclasses.size(); i++){
   //     		System.out.println("@@@@" + superclasses.get(i));
  //      		System.out.println("##" + defaultSuperclass);
  //      	}
        	ovrExtClass = superName;
        	superclassUsage = true;
        }
        
    	detectPackageChange();
    	fieldname.clear();
    	
    	this.methodCounts.clear();
    }
    
    @Override
    public FieldVisitor visitField(int access, String name, String desc,
            String signature, Object value) 
    {
    	fieldCount ++;
    	totalLinesOfCode++;
    	//System.out.println(value + "------" + name + "--" + access + "--" + desc + "--" + signature);
    	if(access == 8){
    		staticFieldCount++;
    	}
    	this.currentFieldName = name;
    	fieldname.add(name);
    	return null;
    }
    

    @Override
    public MethodVisitor visitMethod(int access, String methodName,
            String methodDesc, String signature, String[] exceptions)
    {
    	
    	
    	if(interfaceEncountered){
    		this.intfOvrdnMth.IndintfMthCount++;
    	}
    	
    	String methodInit = "<init>";
    	String methodMain = "main";
    	ovrMethName = methodName;
    	if((!(ovrMethName.equals(methodInit) )) && (!(ovrMethName.equals(methodMain) ))){
    		
    		classMethods.add(ovrMethName);
    		
    	}
    	
    	//System.out.println("metod" + methodName + "@@@@@@@");
    	//this.ovrMeth.methodName = methodName;
    	//overridenMethod.add(ovrMeth);
    	//ovrMeth = null;
    	this.currentMethodName = methodName;
    	methodCount++;
    	
    	if(access == 8){
    		staticMethodCount++;
    	}    	
    	checkGetSetMethod();
    	MethodComplexityCounter methodVisitor = new MethodComplexityCounter(methodName+methodDesc, this);
        return methodVisitor;
    }

    public void setMethodCount(String currentMethod, int predicateCount) {
    //	System.out.println("--" + currentMethod + "--" + predicateCount);
    //	System.out.println("@@" + methodsComplexity);
    	methodsComplexity += predicateCount;
    	
		this.methodCounts.put(currentMethod, predicateCount);
	}
    
    //detecting package change
    public void detectPackageChange(){
    	
    	
    	String currentPackageName;
    	String currentFileName = this.currentClassName;
    	String[] classPathValues = currentFileName.split("/");
    	currentPackageName = classPathValues[classPathValues.length-2];
    	
    	if(packageName.isEmpty()){
    		packageName.add(currentPackageName);
    		//System.out.println(packageName.get(0));
    	}
    	if((packageName.contains(currentPackageName))){
    		//packageName.add(currentPackageName);
    		packageChange = false;
    	}
    	if(!(packageName.contains(currentPackageName))){
    		packageName.add(currentPackageName);
    		packageChange = true;
    		System.out.println("##### Characteristics Matrix: #####");
    		System.out.println("[1] No. of attributes: " + fieldCount );
    		System.out.println("[2] No. of getters and setters: " + setGetMethodCount );
    		methodCount = methodCount - setGetMethodCount;
    		System.out.println("[3] No. of methods: " + methodCount );
    		int packageInterfaceUsage = 0;
    		if(interfaceUsage){
    			 packageInterfaceUsage = 1;
    		}else{
    			 packageInterfaceUsage = 0;
    		}
    		System.out.println("[4] Interface Usage: " + packageInterfaceUsage);
    		
    		int packageSuperclassUsage = 0;
    		if(superclassUsage){
    			packageSuperclassUsage = 1;
    		}else{
    			packageSuperclassUsage = 0;
    		}
    		System.out.println("[5] Superclass Usage: " + packageSuperclassUsage); 
    		System.out.println("[6] No. of static attributes: " + staticFieldCount);
    		System.out.println("[7] No. of static methods: " + staticMethodCount);
    		double meanMethodComplexity = ((methodsComplexity)/(methodCount+setGetMethodCount));
    		System.out.println("[8] Mean method Complexity: " + meanMethodComplexity);
    		double methodsMeanSize = ((totalLinesOfMethods)/(methodCount+setGetMethodCount));
    		System.out.println("[9] Class methods mean size: " + methodsMeanSize);
    		totalLinesOfCode = totalLinesOfCode + totalLinesOfMethods;
    		System.out.println("[10] Total Lines Of Code: " + totalLinesOfCode);
    		System.out.println("[11] Weighted Methods per Class: " + methodsComplexity);
    		
    		for(int i = 0; i < overridenMethod.size(); i++){
    			String className = overridenMethod.get(i).className;
    			int j = i;
    			for(int k = 0; k < overridenMethod.size(); k++){
    				if(j == k){
    					continue;
    				}
    				if(className.equals(overridenMethod.get(k).extendClass)){
    					if(overridenMethod.get(i).methodName.equals(overridenMethod.get(k).methodName)){
    						overridenMethCount++;
    					}
    				}
    			}
    		}
    		
    		System.out.println("[12] No. of Overriden Methods: " + overridenMethCount); 
    		
    		for(int i = 0; i < numbOfChild.size(); i++){
    			
    			NumberOfChildren tmp = numbOfChild.get(i);
    			String defaultSuperClass = "java/lang/Object";
    			if(!(tmp.extendClassName.equals(defaultSuperClass))){
    				continue;
    			}
    			String currentClass = tmp.className;   			
    			int j = i;
                for(int k = 0; k < numbOfChild.size(); k++){
                	if(k == j){
                		continue;
                	}
                	NumberOfChildren tmpOne = numbOfChild.get(k);
                	if(currentClass.equals(tmpOne.extendClassName)){
                		NoOfChildrenCount++;
                	}
                }
    			
    		}
    		
    		
    		System.out.println("[13] No. of Children: " + NoOfChildrenCount);
    		System.out.println("---------------------------------------------");
    		
    		
    		fieldCount = 0;
    		setGetMethodCount = 0;
    		fieldname.clear();
    		methodCount = 0;
    		interfaceUsage = false;
    		superclassUsage = false;
    		superclasses.clear();
    		staticFieldCount = 0;
    		staticMethodCount = 0;
    		methodsComplexity = 0;
    		totalLinesOfMethods = 0;
    		totalLinesOfCode = 0;
    		overridenMethCount = 0;
    		overridenMethod.clear();
    		indIntfClassMth.clear();
    		NoOfChildrenCount = 0;
    		numbOfChild.clear();
    		
    	}
       	
    	
    }
    
    
    public void checkGetSetMethod(){
    	
    String currentMethodName = this.currentMethodName;
    for(int i = 0; i < fieldname.size(); i++){
    	String setFieldName = "set";
    	String getFieldName = "get";
    	setFieldName = setFieldName.concat(fieldname.get(i));
    	getFieldName = getFieldName.concat(fieldname.get(i));
    	if(currentMethodName.equalsIgnoreCase(setFieldName)){
    		setGetMethodCount++;   		
    	}
    	if(currentMethodName.equalsIgnoreCase(getFieldName)){
    		setGetMethodCount++;
    	}    	
    }
    	
    	
    }

    @Override
    public void visitEnd()
    {
    	//System.out.println(ClassFileOpener.jarFileName);
   	
    	for(int i = 0; i < classMethods.size(); i++){        	
    		this.ovrMeth = new OverridenMethods();
    		this.ovrMeth.className = ovrClassName;
        	this.ovrMeth.extendClass = ovrExtClass;
        	this.ovrMeth.methodName = classMethods.get(i);
        	overridenMethod.add(this.ovrMeth);

    	}
    	
    	if(interfaceEncountered){
    		indIntfClassMth.add(this.intfOvrdnMth);
    			// interfaceEncountered = false;		 	
    	}
    	
    	
    	
    	//System.out.println("----------------------------------");
    	ovrClassName = null;
    	ovrExtClass = null;
    	ovrMethName = null;
    	classMethods.clear();
    	
    	
    	
    	this.outfile.print(this);
    }

	@Override
	public String toString() {
		 StringBuilder results = new StringBuilder();
   // 	int classTotal = 0;
   // 	for (Entry<String,Integer> pair : this.methodCounts.entrySet()) {
  //  		results.append(String.format("Method,%s.%s,%d\n", this.currentClassName, pair.getKey(), pair.getValue()));
  //  		classTotal += pair.getValue();
  //  	}
 //   	results.append(String.format("Class,%s,%d\n", this.currentClassName, classTotal));
        if(interfaceEncountered){
        	results.append(String.format(" >> Interface Name: %s\n", this.currentClassName));
        	interfaceEncountered = false;
        }else{
        	results.append(String.format(" > Class Name: %s\n", this.currentClassName));
        }
		
		
//		results.append(String.format("No. of attributes: [%d]\n", this.fieldCount));
		return results.toString();
	}	
	
}
