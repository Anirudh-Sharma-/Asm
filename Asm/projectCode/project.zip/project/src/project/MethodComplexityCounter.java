package project;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Attribute;
import org.objectweb.asm.Handle;
import org.objectweb.asm.AnnotationVisitor;

import project.ClassComplexityCounter;

public class MethodComplexityCounter extends MethodVisitor{
	
	int predicateCount;
	String currentMethod;
	ClassComplexityCounter parentClass;
	
	
	public MethodComplexityCounter(String methodName, ClassComplexityCounter parentClass) 
	{
		super(Opcodes.ASM4);
		this.currentMethod = methodName;
		this.parentClass = parentClass;
		this.predicateCount = 1;  // NB - always predicates+1
		
		
	}
	


	@Override
	public void visitJumpInsn(int opcode, Label label) {
		

		if (opcode != Opcodes.GOTO)
			this.predicateCount ++;
		ClassComplexityCounter.totalLinesOfMethods++;
	}

	@Override
	public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
		ClassComplexityCounter.totalLinesOfMethods++;
		this.predicateCount += labels.length;
	}

	@Override
	public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
		ClassComplexityCounter.totalLinesOfMethods++;
		this.predicateCount += labels.length;
	}
	
	
	@Override
	public void visitAttribute(Attribute attr){
		ClassComplexityCounter.totalLinesOfMethods++;
		
	}
	
	@Override
	public void visitFieldInsn(int opcode, String owner, String name, String desc){
		ClassComplexityCounter.totalLinesOfMethods++;
	}
	
	@Override
	public void visitIincInsn(int var, int increment){
		ClassComplexityCounter.totalLinesOfMethods++;
	}
	
	@Override
	public void visitInsn(int opcode){
		ClassComplexityCounter.totalLinesOfMethods++;
		
	}
	
	@Override
	public void visitIntInsn(int opcode, int operand){
		ClassComplexityCounter.totalLinesOfMethods++;
	}	
	
	@Override
	public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs){
		ClassComplexityCounter.totalLinesOfMethods++;
	}	
	

	
	@Override
	public void visitLdcInsn(Object cst){
		ClassComplexityCounter.totalLinesOfMethods++;
	}
	

	
	@Override
	public void visitMethodInsn(int opcode, String owner, String name, String desc){
		ClassComplexityCounter.totalLinesOfMethods++;

	}
	
	@Override
	public void visitMultiANewArrayInsn(String desc, int dims){
		ClassComplexityCounter.totalLinesOfMethods++;

	}	
	
	@Override
	public void visitTryCatchBlock(Label start, Label end, Label handler, String type){
		ClassComplexityCounter.totalLinesOfMethods++;

	}	
	
	
	@Override
	public void visitTypeInsn(int opcode, String type){
		ClassComplexityCounter.totalLinesOfMethods++;

	}	
	
	@Override
	public void visitVarInsn(int opcode, int var){
		ClassComplexityCounter.totalLinesOfMethods++;

	}	
	

	@Override
	public void visitEnd() {
		ClassComplexityCounter.totalLinesOfMethods++;
		this.parentClass.setMethodCount(this.currentMethod, this.predicateCount);

	}	

}
