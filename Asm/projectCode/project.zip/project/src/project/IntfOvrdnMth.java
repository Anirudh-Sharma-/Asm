package project;

public class IntfOvrdnMth {
	
	public String intfName;
	public int IndintfMthCount;

}
