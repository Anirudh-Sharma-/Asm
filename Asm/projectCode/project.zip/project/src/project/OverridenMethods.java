package project;

public class OverridenMethods {

	String className;
	String methodName;
	String extendClass;
	
}
