package second;

public class Test {

	public int testOne;
	
	public void testMethod() {
		// TODO Auto-generated method stub
		
	}
}
