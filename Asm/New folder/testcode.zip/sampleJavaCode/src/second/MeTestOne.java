package second;



public class MeTestOne extends Test implements shareable{
	public int getFieldOne() {
		return fieldOne;
	}
	public void setFieldOne(int fieldOne) {
		this.fieldOne = fieldOne;
	}
	public float getFieldTwo() {
		return fieldTwo;
	}
//	public void setFieldTwo(float fieldTwo) {
//		this.fieldTwo = fieldTwo;
//	}
	public int fieldOne;
	public float fieldTwo;
	static int fieldThree;
	private float fieldFour;
	
	public void printName(){
		System.out.print("hello world");
	}
	static void incField(){
		fieldThree++;
	}
	
	public void shareMe(){
		System.out.println("share");
	}
	
	@Override
	public void testMethod(){
		//super.testMethod();
		System.out.println("test method in class MeTestOne");
	}
	
	
	public static void main(String[] args){

		MeTestOne one = new MeTestOne();
		one.printName();
	}	

}
