package second;

public interface shareable {
	void shareMe();
		
	
}
