package first;


public class MeTestOne extends Test{
	
	public int fieldOne;
	public float fieldTwo;
	static int fieldThree;

	public int getFieldOne() {
		int local;
		return fieldOne;
	}
	public void setFieldOne(int fieldOne) {
		this.fieldOne = fieldOne;
	}
	public float getFieldTwo() {
		return fieldTwo;
	}
	public void setFieldTwo(float fieldTwo) {
		this.fieldTwo = fieldTwo;
	}

	static void incField(){
		fieldThree++;
	}
	public void printName(){
		System.out.print("hello world");
	}
	public static void main(String[] args){

		MeTestOne one = new MeTestOne();
		one.printName();
	}	
	
}
