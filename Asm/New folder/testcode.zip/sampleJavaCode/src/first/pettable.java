package first;

public interface pettable {
	void petMe();

}
