package first;

public class MeTestSecond implements pettable{
	public int fieldOne;
	public float fieldTwo;
	static int fieldThree;

	public int getFieldOne() {
		return fieldOne;
	}
	public void setFieldOne(int fieldOne) {
		this.fieldOne = fieldOne;
	}
	public float getFieldTwo() {
		return fieldTwo;
	}
	public void setFieldTwo(float fieldTwo) {
		this.fieldTwo = fieldTwo;
	}

	static void incField(){
		fieldThree++;
	}
	static void incFieldOne(){
		fieldThree++;
	}
	public void printName(){
		System.out.print("hello world");
	}
	@Override
	public void petMe(){
		System.out.println("hello");
	}
	public static void main(String[] args){

		MeTestOne one = new MeTestOne();
		one.printName();
	}
}
